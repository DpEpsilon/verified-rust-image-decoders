//! Authored frozen-vector witnesses, independent model expectations followed by
//! actual public calls. This module exists only in the verifier configuration.
use crate::{
    inflate_zlib_into, model as m, InflateError as E, InflateOptions, SegmentSlices, Status,
};
use vstd::prelude::*;

verus! {

/// zlib/empty-idat-only: the extractor supplies Z=[], not no inflate call.
fn empty_idat_only() {
    let wire: [u8; 0] = [];
    proof {
        assert(m::Inflate(seq![], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TruncatedZlib)) by (compute);
        assert(m::Inflate(seq![], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let parts: [&[u8]; 1] = [&wire];
    proof {
        reveal_with_fuel(crate::segments::parts_prefix, 2);
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(parts@[0]@ == wire@);
        assert(crate::segments::parts_prefix(parts@, 1) =~= wire@);
    }
    let mut source = match SegmentSlices::new(&parts) {
        Some(source) => source,
        None => { proof { assert(false); } return; },
    };
    let mut output = [0xa5u8; 4];
    proof {
        assert(output@ =~= seq![0xa5u8, 0xa5, 0xa5, 0xa5]);
    }
    let ghost initial = output@;
    let result = inflate_zlib_into(&mut source, &mut output, InflateOptions::STRICT);
    proof {
        assert(result.status == Status::Err(E::TruncatedZlib));
        assert(result.produced == 0);
        assert(output@.skip(0) == initial.skip(0));
        assert(output@.skip(0) =~= output@);
        assert(initial.skip(0) =~= initial);
        assert(output@ =~= seq![0xa5u8, 0xa5, 0xa5, 0xa5]);
    }
    check_public(&wire, Status::Err(E::TruncatedZlib), Ghost(Seq::<u8>::empty()));
}

/// deflate/stored-only: two grey scanlines have raw bytes [filter, A, filter, B].
fn stored_only() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Done) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let parts: [&[u8]; 1] = [&wire];
    proof {
        reveal_with_fuel(crate::segments::parts_prefix, 2);
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(parts@[0]@ == wire@);
        assert(crate::segments::parts_prefix(parts@, 1) =~= wire@);
    }
    let mut source = match SegmentSlices::new(&parts) {
        Some(source) => source,
        None => { proof { assert(false); } return; },
    };
    let mut output = [0xa5u8; 4];
    proof {
        assert(output@ =~= seq![0xa5u8, 0xa5, 0xa5, 0xa5]);
    }
    let ghost initial = output@;
    let result = inflate_zlib_into(&mut source, &mut output, InflateOptions::STRICT);
    proof {
        assert(result.status == Status::Done);
        assert(result.produced == 4);
        assert(output@ == seq![0u8, 0x41, 0, 0x42]);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Done, Ghost(raw));
}

/// Reusable witness harness: no expected value comes from an executable oracle.
fn check_public(wire: &[u8], expected: Status, raw: Ghost<Seq<u8>>)
    requires wire.len() <= crate::limits::SEGMENT_BYTES_MAX, raw@.len() <= 4,
        crate::status_eq(expected, m::Inflate(wire@, 4, true, false).status),
        raw@ == m::Inflate(wire@, 4, true, false).out,
{
    let parts: [&[u8]; 1] = [wire];
    proof { reveal_with_fuel(crate::segments::parts_prefix, 2);
        assert(crate::segments::parts_prefix(parts@, 1) =~= wire@); }
    let mut source = match SegmentSlices::new(&parts) {
        Some(source) => source,
        None => { proof { assert(false); } return; },
    };
    let mut output = [0xa5u8; 4];
    let result = inflate_zlib_into(&mut source, &mut output, InflateOptions::STRICT);
    proof {
        assert(result.status == expected);
        assert(result.produced == raw@.len());
        assert(output@.take(result.produced as int) == raw@);
    }
    let mut source = match SegmentSlices::new(&parts) {
        Some(source) => source,
        None => { proof { assert(false); } return; },
    };
    let mut ring = [0xccu8; crate::limits::WINDOW_MAX];
    proof { crate::limits::caps_ok(); assert(crate::limits::WINDOW_MAX == 32768) by (compute); assert(ring@.len() == crate::limits::WINDOW_MAX); }
    let measured = crate::inflate_zlib_measure(&mut source, &mut ring, 4, InflateOptions::STRICT);
    proof {
        assert(measured.status == expected);
        assert(measured.produced == raw@.len());
        assert(crate::ring_repr(ring@, raw@));
    }
}


/// zlib/cm-7: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_cm_7() {
    let wire = [0x77u8, 0x09, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(m::Inflate(seq![0x77u8, 0x09, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::UnsupportedZlibMethod)) by (compute);
        assert(m::Inflate(seq![0x77u8, 0x09, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::UnsupportedZlibMethod), Ghost(Seq::<u8>::empty()));
}

/// zlib/cinfo-8: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_cinfo_8() {
    let wire = [0x88u8, 0x1c, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(m::Inflate(seq![0x88u8, 0x1c, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::UnsupportedZlibMethod)) by (compute);
        assert(m::Inflate(seq![0x88u8, 0x1c, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::UnsupportedZlibMethod), Ghost(Seq::<u8>::empty()));
}

/// zlib/fdict: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_fdict() {
    let wire = [0x78u8, 0xbb, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 19) by (compute);
        assert(m::Inflate(seq![0x78u8, 0xbb, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::ZlibPresetDictionary)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0xbb, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::ZlibPresetDictionary), Ghost(Seq::<u8>::empty()));
}

/// zlib/one-byte: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_one_byte() {
    let wire = [0x78u8];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 1) by (compute);
        assert(m::Inflate(seq![0x78u8], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TruncatedZlib)) by (compute);
        assert(m::Inflate(seq![0x78u8], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::TruncatedZlib), Ghost(Seq::<u8>::empty()));
}

/// zlib/bad-adler: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_bad_adler() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x00, 0x00, 0x00, 0x01];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x00, 0x00, 0x00, 0x01], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::AdlerMismatch)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x00, 0x00, 0x00, 0x01], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::AdlerMismatch), Ghost(raw));
}

/// zlib/missing-adler: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_missing_adler() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 11) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TruncatedZlib)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::TruncatedZlib), Ghost(raw));
}

/// zlib/partial-adler: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_partial_adler() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 13) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TruncatedZlib)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::TruncatedZlib), Ghost(raw));
}

/// zlib/trailing-byte: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_trailing_byte() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x00];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 16) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x00], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TrailingZlibData)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x00], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::TrailingZlibData), Ghost(raw));
}

/// zlib/second-stream: R=4 for the authored 1x2, 8-bit grey image.
fn zlib_second_stream() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x78, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 30) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x78, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::TrailingZlibData)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84, 0x78, 0x01, 0x01, 0x04, 0x00, 0xfb, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == seq![0u8, 0x41, 0, 0x42]) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::TrailingZlibData), Ghost(raw));
}

/// deflate/stored-nlen: R=4 for the authored 1x2, 8-bit grey image.
fn deflate_stored_nlen() {
    let wire = [0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfa, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84];
    proof {
        assert(crate::limits::SEGMENT_BYTES_MAX >= 15) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfa, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).status == m::InflateStatus::Error(m::InflateFault::StoredLengthMismatch)) by (compute);
        assert(m::Inflate(seq![0x78u8, 0x01, 0x01, 0x04, 0x00, 0xfa, 0xff, 0x00, 0x41, 0x00, 0x42, 0x01, 0x09, 0x00, 0x84], 4, true, false).out == Seq::<u8>::empty()) by (compute);
    }
    let ghost raw = seq![0u8, 0x41, 0, 0x42];
    check_public(&wire, Status::Err(E::StoredLengthMismatch), Ghost(Seq::<u8>::empty()));
}

} // verus!
