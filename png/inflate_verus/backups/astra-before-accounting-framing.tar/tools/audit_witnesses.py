#!/usr/bin/env python3
"""Check authored witness input provenance without consulting an inflate oracle."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def idat(data):
    pos = 8
    parts = []
    while pos + 12 <= len(data):
        size = int.from_bytes(data[pos:pos + 4], 'big')
        assert pos + 12 + size <= len(data)
        if data[pos + 4:pos + 8] == b'IDAT':
            parts.append(data[pos + 8:pos + 8 + size])
        pos += 12 + size
    assert parts, 'This checker covers the authored IDAT witness subset only'
    return b''.join(parts)


def main():
    vectors = {v['name']: v for v in json.loads((ROOT.parent / 'spec-frozen/VECTORS.json').read_text())}
    text = (ROOT / 'src/witnesses.rs').read_text()
    pattern = re.compile(r'/// ([\w/-]+):[^\n]*\nfn \w+\(\) \{\s*let wire(?:\s*:\s*\[u8;\s*0\])?\s*=\s*\[([^\]]*)\]', re.M)
    seen = set()
    for name, elements in pattern.findall(text):
        wire = bytes(int(x.strip().removesuffix('u8'), 0) for x in elements.split(',') if x.strip())
        assert name not in seen, name
        assert wire == idat(bytes.fromhex(vectors[name]['input_hex'])), name
        seen.add(name)
    # This is the authored subset, not a claim of coverage of all 631 streams.
    assert len(seen) == 12, (len(seen), sorted(seen))
    assert 'zlib/empty-idat-only' in seen
    print(f'{len(seen)} authored witness streams match frozen IDAT extraction, including Z=[]; no oracle used')


if __name__ == '__main__':
    main()
