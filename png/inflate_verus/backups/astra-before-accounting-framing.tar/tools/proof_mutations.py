#!/usr/bin/env python3
"""Run one implementation-only proof mutation in a durable disposable copy.

The copy shares the pre-seeded target directory; this script never removes a
source or target directory. Every verifier invocation uses the copied verify.sh,
with its original flags, lock and timeout. Logs append to the main run inventory.
"""
import argparse
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
CASES = {
    'omit-nlen': ('if len != !nlen { return Err(Status::Err(E::StoredLengthMismatch)); }',
                  'if false { return Err(Status::Err(E::StoredLengthMismatch)); }'),
    'wrong-length-285': ('163, 195, 227, 258,', '163, 195, 227, 257,'),
    'omit-window-guard': ('if distance > output.produced || distance > window {',
                          'if distance > output.produced {'),
    'wrong-copy-offset': ('let byte = output.previous(distance);',
                          'let byte = output.previous(1);'),
    'full-at-limit': ('if self.produced == self.limit {',
                      'if self.produced + 1 == self.limit {'),
    'omit-copy-charge': ('w.add(1);\n        let byte = output.previous(distance);',
                         'let byte = output.previous(distance);'),
    'reserved-length-286-admitted': ('if sym > 285 {', 'if sym > 286 {'),
    'early-bfinal': ('Ok(last) => if last { return Ok(()); },',
                     'Ok(last) => if true { return Ok(()); },'),
    'omit-adler-comparison': ('if expected != output.adler.finish() {',
                             'if false {'),
    'ignore-short-tail': ('if ignore_tail && output.produced == output.limit {',
                          'if ignore_tail {'),
    'omit-fcheck': ('if (cmf as u16 * 256 + flg as u16) % 31 != 0 {',
                    'if false {'),
    'little-endian-checksum': ('expected = (expected << 8) | byte as u32;',
                               'expected = (expected >> 8) | ((byte as u32) << 24);'),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=CASES)
    args = parser.parse_args()
    dest = ROOT / 'mutation-cases' / args.case
    assert not dest.exists(), f'Keep existing diagnostics; choose another case: {dest}'
    dest.mkdir(parents=True)
    for name in ('src', 'tools', 'examples', 'tests'):
        shutil.copytree(ROOT / name, dest / name)
    for name in ('Cargo.toml', 'Cargo.lock', 'verify.sh'):
        shutil.copy2(ROOT / name, dest / name)
    for name in ('target', 'runs', 'RUNLOG.tsv'):
        (dest / name).symlink_to(ROOT / name, target_is_directory=name != 'RUNLOG.tsv')
    source = dest / 'src/inflate.rs'
    text = source.read_text()
    before, after = CASES[args.case]
    assert text.count(before) == 1, (args.case, text.count(before))
    source.write_text(text.replace(before, after))
    result = subprocess.run(['timeout', '25m', str(dest / 'verify.sh'),
                             f'Proof mutation {args.case} (disposable source copy)'],
                            timeout=1530)
    row = (ROOT / 'RUNLOG.tsv').read_text().splitlines()[-1]
    match = re.search(r'verification results:: (\d+) verified, (\d+) errors', row)
    assert result.returncode != 0 and match and int(match[2]) > 0, row
    print(f'MUTATION KILLED: {args.case}; {match[1]} verified, {match[2]} errors')


if __name__ == '__main__':
    main()
