#!/usr/bin/env python3
"""Run one implementation-only proof mutation in a durable disposable copy.

The copy shares the pre-seeded target directory; this script never removes a
source or target directory. Every verifier invocation uses the copied verify.sh,
with its original flags, lock and timeout. Logs append to the main run inventory.
"""
import argparse
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
CASES = {
    'omit-nlen': ('if len != !nlen { return Err(Status::Err(E::StoredLengthMismatch)); }',
                  'if false { return Err(Status::Err(E::StoredLengthMismatch)); }'),
    'wrong-length-285': ('163, 195, 227, 258,', '163, 195, 227, 257,'),
    'omit-window-guard': ('if distance > output.produced || distance > window {',
                          'if distance > output.produced {'),
    'wrong-copy-offset': ('let byte = output.previous(distance);',
                          'let byte = output.previous(1);'),
    'full-at-limit': ('if self.produced == self.limit {',
                      'if self.produced + 1 == self.limit {'),
    'omit-copy-charge': ('w.add(1);\n        let byte = output.previous(distance);',
                         'let byte = output.previous(distance);'),
    'reserved-length-286-admitted': ('if sym > 285 {', 'if sym > 286 {'),
    'early-bfinal': ('Ok(last) => if last { return Ok(()); },',
                     'Ok(last) => if true { return Ok(()); },'),
    'omit-adler-comparison': ('if expected != output.adler.finish() {',
                             'if false {'),
    'ignore-short-tail': ('if ignore_tail && output.produced == output.limit {',
                          'if ignore_tail {'),
    'omit-fcheck': ('if (cmf as u16 * 256 + flg as u16) % 31 != 0 {',
                    'if false {'),
    'little-endian-checksum': ('expected = (expected << 8) | byte as u32;',
                               'expected = (expected >> 8) | ((byte as u32) << 24);'),
}


FILE_CASES = {
    'reader-wrong-byte': ('segments.rs', 'let byte = part[self.offset];', 'let byte = 0u8;'),
    'reader-skip-empty-position': ('segments.rs', 'self.offset = 0;\n            proof { self.seg_work', 'self.offset = 1;\n            proof { self.seg_work'),
    'reader-first-eof-double-charge': ('segments.rs', 'self.end_reported = true;\n                    proof', 'self.end_reported = true;\n                    proof { self.read_work = Ghost(self.read_work@ + 1); }\n                    proof'),
    'reader-omit-segment-charge': ('segments.rs', 'self.offset = 0;\n            proof { self.seg_work = Ghost(self.seg_work@ + 1); }', 'self.offset = 0;'),
    'bits-wrong-shift': ('bits.rs', 'self.current >>= 1;', 'self.current <<= 1;'),
    'bits-wrong-alignment': ('bits.rs', 'self.current = 0;\n        self.remaining = 0;', 'self.current = 0;\n        self.remaining = 1;'),
    'bits-misclassify-first-eof': ('bits.rs', 'w.observed@ + self.src.core_steps() - before', 'w.observed@ + 1'),
    'huffman-lsb-first': ('huffman.rs', 'code = code * 2 + bit;', 'code = code + (bit << n);'),
    'huffman-accept-incomplete': ('huffman.rs', 'if admissible {', 'if true {'),
    'huffman-skip-dead-prefix': ('huffman.rs', 'if code < first || code - first - count >= self.live[n] {', 'if false {'),
    'huffman-empty-as-truncated': ('huffman.rs', 'return Err(InflateError::InvalidSymbol);\n        }\n        let mut code', 'return Err(InflateError::TruncatedZlib);\n        }\n        let mut code'),
    'huffman-omit-init-charge': ('huffman.rs', 'w.add(HUFF_INIT_STEPS);', 'w.add(0);'),
    'dynamic-cl-permutation': ('inflate.rs', 'cl[CL_ORDER[i]] = value as u8;', 'cl[i] = value as u8;'),
    'dynamic-repeat-overflow': ('inflate.rs', 'if repeat > total - i {', 'if false {'),
    'dynamic-wrong-repeat-fill': ('inflate.rs', 'write_length_repeat(&mut lengths, i, repeat, value, w)', 'write_length_repeat(&mut lengths, i, repeat, 0, w)'),
    'dynamic-omit-eob-check': ('inflate.rs', 'if lengths[256] == 0 {', 'if false {'),
    'dynamic-count-before-third': ('inflate.rs', 'let ncode = match br.get(4, w)', 'if nlen > NLIT_MAX || ndist > NDIST_MAX { return Err(E::InvalidCodeLengths); }\n        let ncode = match br.get(4, w)'),
    'dynamic-repeat16-read-before-previous': ('inflate.rs', 'if i == 0 { return (Err(E::InvalidCodeLengths), Ghost(construction)); }\n                    let extra = match br.get(2, w) {\n                        Ok(extra) => extra, Err(e) => return (Err(e), Ghost(construction)),\n                    };', 'let extra = match br.get(2, w) {\n                        Ok(extra) => extra, Err(e) => return (Err(e), Ghost(construction)),\n                    };\n                    if i == 0 { return (Err(E::InvalidCodeLengths), Ghost(construction)); }'),
    'fixed-only-thirty-distances': ('inflate.rs', 'let dist_lengths = [5u8; FIXED_DIST_COUNT];', 'let dist_lengths = [5u8; NDIST_MAX];'),
    'btype-swap-fixed-dynamic': ('inflate.rs', 'match typ {', 'match if typ == 1 { 2 } else if typ == 2 { 1 } else { typ } {'),
    'distance-output-plus-one': ('inflate.rs', 'if distance > output.produced || distance > window {', 'if distance > output.produced + 1 || distance > window {'),
    'distance-wrong-base': ('inflate.rs', 'let distance = DIST_BASE[ds] as u64 + de as u64;', 'let distance = DIST_BASE[ds] as u64 + de as u64 + 1;'),
    'distance-wrong-extras': ('inflate.rs', 'br.get(DIST_EXTRA[ds], w)', 'br.get(0, w)'),
    'reserved-distance-admitted': ('inflate.rs', 'if ds >= NDIST_MAX {', 'if ds > NDIST_MAX {'),
    'output-omit-limit-guard': ('inflate.rs', 'if self.produced == self.limit {', 'if false {'),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=list(CASES) + list(FILE_CASES))
    args = parser.parse_args()
    if args.case in FILE_CASES:
        filename, before, after = FILE_CASES[args.case]
    else:
        filename = 'inflate.rs'
        before, after = CASES[args.case]
    text = (ROOT / 'src' / filename).read_text()
    assert text.count(before) == 1, (args.case, text.count(before))
    dest = ROOT / 'mutation-cases' / args.case
    assert not dest.exists(), f'Keep existing diagnostics; choose another case: {dest}'
    dest.mkdir(parents=True)
    for name in ('src', 'tools', 'examples', 'tests'):
        shutil.copytree(ROOT / name, dest / name)
    for name in ('Cargo.toml', 'Cargo.lock', 'verify.sh'):
        shutil.copy2(ROOT / name, dest / name)
    for name in ('target', 'runs', 'RUNLOG.tsv'):
        (dest / name).symlink_to(ROOT / name, target_is_directory=name != 'RUNLOG.tsv')
    source = dest / 'src' / filename
    source.write_text(text.replace(before, after))
    result = subprocess.run(['timeout', '25m', str(dest / 'verify.sh'),
                             f'Proof mutation {args.case} (disposable source copy)'],
                            timeout=1530)
    row = (ROOT / 'RUNLOG.tsv').read_text().splitlines()[-1]
    match = re.search(r'verification results:: (\d+) verified, (\d+) errors', row)
    assert result.returncode != 0 and match and int(match[2]) > 0, row
    print(f'MUTATION KILLED: {args.case}; {match[1]} verified, {match[2]} errors')


if __name__ == '__main__':
    main()
