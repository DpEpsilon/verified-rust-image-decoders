//! Verified first-code and symbol-offset construction; the actual Huffman
//! constructor calls this function. No executable tables enter the model.
use crate::limits::*;
#[cfg(verus_only)]
use crate::model as m;
use vstd::prelude::*;

verus! {

pub fn first_codes(lengths: &[u8], counts: &[u16; MAX_CODE_BITS + 1],
    first: &mut [u32; MAX_CODE_BITS + 1], offsets: &mut [u16; MAX_CODE_BITS + 1],
    next: &mut [u16; MAX_CODE_BITS + 1]) -> (steps: usize)
    requires
        m::lengths_ok(lengths@), m::Kraft(lengths@) <= CODE_SPACE,
        counts@[0] == 0,
        forall|n: int| 1 <= n <= MAX_CODE_BITS ==> counts@[n] == m::bl_count(lengths@, n as nat),
    ensures
        steps == MAX_CODE_BITS,
        forall|n: int| 0 <= n <= MAX_CODE_BITS ==>
            final(first)@[n] == m::next_code(lengths@, n as nat),
        forall|n: int| 0 <= n <= MAX_CODE_BITS ==>
            final(offsets)@[n] == m::shorter_prefix(lengths@, n as nat, lengths@.len()),
        forall|n: int| 0 <= n <= MAX_CODE_BITS ==> final(next)@[n] == final(offsets)@[n],
{
    proof { huffman_format_ok(); m::lemma_shorter_small(lengths@, 0, lengths@.len()); }
    first[0] = 0;
    offsets[0] = 0;
    next[0] = 0;
    let mut n = 1usize;
    while n <= MAX_CODE_BITS
        invariant
            1 <= n <= MAX_CODE_BITS + 1,
            m::lengths_ok(lengths@), m::Kraft(lengths@) <= CODE_SPACE,
            counts@[0] == 0,
            forall|j: int| 1 <= j <= MAX_CODE_BITS ==> counts@[j] == m::bl_count(lengths@, j as nat),
            forall|j: int| 0 <= j < n ==> first@[j] == m::next_code(lengths@, j as nat),
            forall|j: int| 0 <= j < n ==> offsets@[j] == m::shorter_prefix(lengths@, j as nat, lengths@.len()),
            forall|j: int| 0 <= j < n ==> next@[j] == offsets@[j],
        decreases MAX_CODE_BITS + 1 - n,
    {
        proof {
            huffman_format_ok();
            m::lemma_canonical_capacity(lengths@, n as nat);
            m::lemma_pow2_monotone(n as nat, MAX_CODE_BITS as nat);
            m::lemma_shorter_recurrence(lengths@, n as nat);
            m::lemma_shorter_bound(lengths@, n as nat, lengths@.len());
            assert(counts@[(n - 1) as int] == m::bl_count(lengths@, (n - 1) as nat));
        }
        first[n] = (first[n - 1] + counts[n - 1] as u32) * 2;
        offsets[n] = offsets[n - 1] + counts[n - 1];
        next[n] = offsets[n];
        n += 1;
    }
    n - 1
}

} // verus!
