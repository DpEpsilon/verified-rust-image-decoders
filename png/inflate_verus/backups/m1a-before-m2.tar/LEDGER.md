# Inflate M1a ledger

2026-11-17 checkpoint. Plain Rust implementation complete for the implemented Strict/RecommendedBeta option domain. **Verus verified count: 0; verifier runs: 0.** No theorem row or named lemma is proved. This is the requested handback after M1a, not an M2 or release declaration.

All run output is under `/home/ws/projects/verified-decoders/png/inflate_verus/runs/`; `/home/ws/projects/verified-decoders/png/inflate_verus/RUNLOG.tsv` records the commands, exits and durations. The filesystem resolves `/home/ws` to the mounted volume, so the TSV contains equivalent absolute volume paths.

| Runs | Evidence | Result |
|---|---|---|
| 1 | Initial debug contract suite | 7 passed |
| 2–3 | Release adapter; all extractor streams and ring smoke | Passed |
| 4 | Original full differential: 10,000 streams and 10,000 single-bit corruptions | Passed, 223.55 seconds, no unexpected differences |
| 5 | First source scan | Failed: the scanner conservatively flagged the nonallocating Adler/output methods named `push` |
| 6–7 | Initial i686 and freestanding thumbv7m library builds | Passed |
| 8 | Source scan after renaming those methods, scanner controls, cap controls, frozen hashes | Passed |
| 9 | Rust formatting | Passed |
| 10 | Final formatted-source debug suite | 7 passed; the label mentions release too, but this command was debug only |
| 11 | Final release differential adapter build | Passed |
| 12 | Final source, seed 1: 5,000 streams and 5,000 corruptions | Passed, 117.48 seconds, no unexpected differences |
| 13 | Final source, seed 2: 5,000 streams and 5,000 corruptions | Passed, 124.07 seconds, no unexpected differences |
| 14 | Final-source release suite | 7 passed |
| 15–16 | Final-source i686 and freestanding thumbv7m no_std builds | Passed |
| 17 | Final source scan, both scanner modes and controls, caps lint controls, twelve frozen hashes | Passed |

Each final differential shard runs 16,772 public-entry pairs: 4,724 vector-stream/layout requests, 48 ring/overlap requests, 10,000 valid/corrupt random requests and 2,000 limit/truncation requests. Every pair calls both `inflate_zlib_into` and `inflate_zlib_measure`. Across the two final shards, that is 33,544 pairs or 67,088 actual public calls. The final shards together contain the required 10,000 generated zlib streams and 10,000 single-bit corruptions. Each shard repeats all vectors and deterministic stress cases.

The vector-stream inventory is 631 frozen, 140 cap-dependent and 410 policy-labelled streams, for 1,181 streams. Four layouts include original PNG payload boundaries and empty segments. The harness explicitly marks 278 non-R cases with invalid or excessively large raw shapes; seven are frozen malformed-header/container records. It does not claim whole-PNG conformance on all 810 records. All inflate-specific M2 gate records use actual image R. The five D4 witnesses and `zlib/empty-idat-only` execute against authored errors; D5 has eight direct stored-prefix/limit cases. Forty-four frozen inflate-error expectations are checked directly against vector intent. General prefixes and success raw bytes use the frozen reference and are not independently authored model witnesses.

## Scope

The library is dependency-free `no_std`, without `alloc`, matching the frozen manifest rather than the task's initial `no_std+alloc` wording. Huffman state uses fixed arrays; both output and the measuring ring belong to the caller. `png_verus`, not this crate, will reserve `IccWindow` through the pinned guard. There is no guard copy or allocation log in this crate.

Runtime coverage includes stored/fixed/dynamic blocks, canonical admissibility, dead-prefix rejection, 32 fixed distance codes, window and overlap cases, exactly-full versus surplus output, Adler deferral, original and artificial segment boundaries, repeated EOF, one million empty segments, and a u64 measuring limit. The adapter checks status, count, exact written prefix, untouched suffix, last-window ring contents and observed core/segment work bounds on every request.

The current option type contains only the field values needed for Strict and RecommendedBeta. ImageCrateCompat-labelled vectors are extracted and exercised under Strict, not credited as compatibility semantics. `IgnoreTail` follows the manifest's exactly-L condition; the direct non-frozen policy-oracle wrapper is less restrictive for short output. No frozen Strict erratum is needed for this discrepancy.

## Unproved

There is no independent mathematical model, Verus public-entry contract or lemma. T-HUFF/L-CANON, L-PREFIX-FREE, T-INFL, T-SEG/L-BITS, L-WINDOW/L-RING, L-LIMIT/L-LIMIT-MONO, L-ADLER/L-HDR-BITS, T1/T11/T12, caps_ok, model witnesses and proof mutations all remain open. The runtime counters are u128 diagnostics and must become erased ghost observations. The allocation source scan and no_std builds are not a signed production call-graph audit or a proof of A-PNG rows.

The public-entry definitions are in `/home/ws/projects/verified-decoders/png/inflate_verus/src/inflate.rs`; the exact next proof-layer steps are in `/home/ws/projects/verified-decoders/png/inflate_verus/STUCK.md`. Start with independent canonical words and Kraft/admissibility, and separate representation construction from dynamic admissibility rejection so T-HUFF(a) covers all non-oversubscribed vectors.

Rustc is 1.99.1 (`58cf8f9c3`, 2026-10-13); cargo is 1.99.1 (`5f94df478`, 2026-08-27). No Verus/vstd artifact was used. `verify.sh` is prepared for serial, bounded M2 verification and refuses a plain-Rust zero-obligation run. No solver-limit change, assumption, admission, external body, unsafe block or new axiom was introduced. No frozen, errata or release-gate file changed; no commit was made; no background process remains.
