# M1a checkpoint; M2 not started

2026-11-17. Plain Rust runtime checks pass. **Verified count: zero. No lemma name or file location can be cited as a completed proof.** No frozen statement has been shown unsatisfiable; no erratum was written or applied.

The new crate lives at `/home/ws/projects/verified-decoders/png/inflate_verus`. Only this directory was created or changed by this task. There is no `model.rs`, Verus dependency, `verus!` block, proof stub, solver-limit override or new trusted item. No existing verification cache was removed.

## Evidence available

- Runs 12–13 test the final-source decoder against Python zlib on 5,000 generated streams and 5,000 single-bit corruptions per seed, with seeds 1 and 2 and zero unexpected differences.
- Each differential run compares all 631 frozen extractor streams and the 550 cap/policy extractor streams across four segment layouts.
- Each runner request calls both public entry points, compares their observations, checks the complete written prefix and untouched suffix, checks last-window contents, and asserts the two observed work bounds.
- The five D4 cases, empty `Z`, eight extractor-presence cases, D5 stored-prefix cases, Adler deferral, wrapping matches, repeated EOF and one million empty segments execute successfully.
- Run 17 passes both GIF allocation-scanner modes, its 44-construct controls, the cap-lint controls and all twelve frozen hashes.
- Runs 15–16 build the final dependency-free no_std library for i686 and freestanding thumbv7m; runs 10 and 14 pass seven Rust contract tests in debug and release builds.

The runner bounds the output buffer for 278 extractor streams with invalid or enormous raw shapes, including seven frozen malformed-header/container records. Those are non-R runtime comparisons, not M2 gates. Every inflate-specific M2 record uses its actual image R. Policy records labelled ImageCrateCompat currently exercise Strict inflate, not compatibility semantics. Forty-four authored frozen inflate errors are checked directly; other raw-byte observations come from the frozen reference, not authored expectations.

## Precise resume point

1. Preserve the M1a source snapshot before converting files. Add the pinned vstd version `=0.0.0-2026-11-01-0251` without its alloc feature. Do not copy GIF's alloc-enabled dependency configuration into this crate. Inspect the prebuilt vstd hash and feature compatibility before copying `/home/ws/projects/verified-decoders/gif/gif_verus/target/debug`; never delete any `target/debug` directory.
2. Start the Huffman layer. Add an independent mathematical `Kraft`, `admissible`, `cw` and prefix-match `MDec` in `model.rs`. The model must not read executable counts, symbol arrays, ring state, transitions or the Python oracle. Define canonical words by their own RFC recurrence over the length sequence.
3. Prove exact Kraft accumulation and admissibility, then L-PREFIX-FREE and L-CANON, then dead-prefix/truncation decoding. The current `Huffman::build` populates first codes and symbols only after admissibility succeeds. T-HUFF(a) also concerns non-oversubscribed but inadmissible vectors; separate canonical representation from the dynamic admissibility decision, or populate the non-oversubscribed representation before returning that rejection. This is implementation work, not a frozen-spec contradiction.
4. Convert `Bits` and `Segments` to verified contracts without narrowing their input domain. T-SEG needs immutable ghost `concat`, ghost cursor/segment views, `wf`, fresh-cursor requirements and both per-read work/termination clauses. `Bits` currently caches only one byte; its ghost bit position is `8*src.pos()-remaining` in `nat`, never a u32 position.
5. Continue through block/window, T-INFL/limit/Adler, segments/work, then allocation facts and independent witnesses, with a handback after each assigned layer.

Use `/home/ws/projects/verified-decoders/png/inflate_verus/verify.sh` for every verifier run. It currently refuses this plain-Rust tree rather than reporting a misleading green zero-obligation result. It bounds verification at 25 minutes, sets one cargo job, uses two verifier threads and `--no-cheating`, and checks a shared lock plus already-running legacy verifier commands. No verifier run has occurred.

## Gaps that must not be hidden

The current `core_steps` and `seg_steps` fields are runtime `u128`, not erased `Ghost<nat>`. Move observations into ghost state at the actual loops; do not verify a wrapper that changes production behaviour. Observed inequalities are not T12. `caps_ok`, symbolic proof use of caps and CAPS-SYM remain open; the six PNG caps do not belong in this crate. The cap lint is a lexical falsification gate, not a constant-expression proof.

Public `inflate_zlib_measure` requires `ring.len() == WINDOW_MAX`; it panics for a caller that violates that documented precondition. M2 must prove panic freedom under the exact permitted preconditions, not silently strengthen them. `Segments` is currently a prose contract, so arbitrary unverified trait implementations do not carry a universal correctness guarantee.

The implemented policy domain contains only Strict/RecommendedBeta field values, not all Stage-2 tuples. `IgnoreTail` requires exactly-L output after a matching checksum, per the manifest. The current policy oracle's direct wrapper ignores a trailing stream even for a short output; the test wrapper deliberately follows the manifest's restriction. No frozen Strict rule depends on this non-frozen policy discrepancy.

There is no independent evolving sequence-output inflate model, T-INFL public-entry refinement, L-WINDOW/L-RING/L-LIMIT/L-ADLER proof, safety/termination proof, symbolic work proof, model-versus-authored witness proof, or verifier mutation kill. A-PNG's no-alloc property has only source/dependency/build evidence here; the PNG crate's reservations and sealed log belong to later work. No signed production call-graph audit or physical/logical allocation audit is claimed.

The original long differential run completed, but the tool harness automatically detached it after three minutes despite a foreground request. It exited successfully and left no process running. Final-source runs were split into bounded foreground shards below that threshold. No background job remains; no commit, durable /tmp content, erratum edit or release-gate edit was made.
