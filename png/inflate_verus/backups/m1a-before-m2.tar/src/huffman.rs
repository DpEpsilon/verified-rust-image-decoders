use crate::{bits::Bits, limits::*, InflateError, Segments, Work};

#[derive(Clone, Copy)]
pub(crate) enum Kind {
    CodeLen,
    LitLen,
    Dist,
}

/// Counts, first canonical code, first symbol index, and symbol order. Only
/// symbols in 0..nsyms are readable; rebuilding never clears unused symbol slots.
pub(crate) struct Huffman {
    count: [u16; MAX_CODE_BITS + 1],
    first: [u32; MAX_CODE_BITS + 1],
    offset: [u16; MAX_CODE_BITS + 1],
    symbol: [u16; FIXED_LIT_COUNT],
    live: [u32; MAX_CODE_BITS + 1],
    nsyms: usize,
}
impl Huffman {
    pub fn new(w: &mut Work) -> Self {
        w.add(4 * (MAX_CODE_BITS + 1) + FIXED_LIT_COUNT);
        Self {
            count: [0; MAX_CODE_BITS + 1],
            first: [0; MAX_CODE_BITS + 1],
            offset: [0; MAX_CODE_BITS + 1],
            symbol: [0; FIXED_LIT_COUNT],
            live: [0; MAX_CODE_BITS + 1],
            nsyms: 0,
        }
    }
    pub fn build(&mut self, lengths: &[u8], kind: Kind, w: &mut Work) -> Result<(), InflateError> {
        if lengths.len() > FIXED_LIT_COUNT {
            return Err(InflateError::InvalidCodeLengths);
        }
        self.nsyms = 0;
        let mut n = 0;
        while n <= MAX_CODE_BITS {
            w.add(1);
            self.count[n] = 0;
            n += 1;
        }
        let mut kraft = 0u32;
        let mut s = 0;
        while s < lengths.len() {
            w.add(1);
            let len = usize::from(lengths[s]);
            if len > MAX_CODE_BITS {
                return Err(InflateError::InvalidCodeLengths);
            }
            if len != 0 {
                self.count[len] += 1;
                kraft += 1u32 << (MAX_CODE_BITS - len);
                self.nsyms += 1;
            }
            s += 1;
        }
        // Exact Kraft rejection precedes every canonical-code calculation and
        // lookup. Even an oversubscribed input fits the u32 accumulator.
        if kraft > CODE_SPACE {
            return Err(InflateError::InvalidCodeLengths);
        }
        let complete = kraft == CODE_SPACE;
        let admissible = complete
            || match kind {
                Kind::CodeLen => false,
                Kind::LitLen => self.nsyms == 1 && self.count[1] == 1,
                Kind::Dist => self.nsyms == 0 || (self.nsyms == 1 && self.count[1] == 1),
            };
        if !admissible {
            return Err(InflateError::InvalidCodeLengths);
        }
        let mut next = [0u16; MAX_CODE_BITS + 1];
        w.add(MAX_CODE_BITS + 1);
        self.first[0] = 0;
        self.offset[0] = 0;
        n = 1;
        while n <= MAX_CODE_BITS {
            w.add(1);
            self.first[n] = (self.first[n - 1] + u32::from(self.count[n - 1])) << 1;
            self.offset[n] = self.offset[n - 1] + self.count[n - 1];
            next[n] = self.offset[n];
            n += 1;
        }
        s = 0;
        while s < lengths.len() {
            w.add(1);
            let len = usize::from(lengths[s]);
            if len != 0 {
                self.symbol[usize::from(next[len])] = s as u16;
                next[len] += 1;
            }
            s += 1;
        }
        // In canonical order the proper prefixes immediately follow length-n
        // codewords. Round the remaining Kraft mass up to n-bit prefixes.
        let mut higher = 0u32;
        n = MAX_CODE_BITS;
        loop {
            w.add(1);
            let unit = 1u32 << (MAX_CODE_BITS - n);
            self.live[n] = higher.div_ceil(unit);
            if n == 0 {
                break;
            }
            higher += u32::from(self.count[n]) * unit;
            n -= 1;
        }
        Ok(())
    }
    pub fn decode<S: Segments>(
        &self,
        br: &mut Bits<'_, S>,
        w: &mut Work,
    ) -> Result<u16, InflateError> {
        if self.nsyms == 0 {
            return Err(InflateError::InvalidSymbol);
        }
        let mut code = 0u32;
        let mut n = 1;
        while n <= MAX_CODE_BITS {
            w.add(1);
            code = (code << 1) | br.get(1, w)?;
            let first = self.first[n];
            let count = u32::from(self.count[n]);
            if code >= first && code - first < count {
                return Ok(self.symbol[usize::from(self.offset[n]) + (code - first) as usize]);
            }
            if code < first || code - first - count >= self.live[n] {
                return Err(InflateError::InvalidSymbol);
            }
            n += 1;
        }
        Err(InflateError::InvalidSymbol)
    }
}
