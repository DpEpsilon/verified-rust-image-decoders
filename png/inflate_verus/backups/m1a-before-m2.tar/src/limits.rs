//! Format and work constants named by the frozen manifest. The six PNG resource
//! caps belong to png_verus, not to this allocation-free crate. M2's caps_ok
//! lemma and symbolic-cap lint are still outstanding.
pub const MAX_CODE_BITS: usize = 15;
pub const WINDOW_MAX: usize = 1 << 15;
pub const LEN_MAX: usize = 258;
pub const NLIT_MAX: usize = 286;
pub const NDIST_MAX: usize = 30;
pub const NCL: usize = 19;
pub const FIXED_LIT_COUNT: usize = 288;
pub const FIXED_DIST_COUNT: usize = 32;
pub const DYNAMIC_LENGTHS: usize = NLIT_MAX + NDIST_MAX;
pub const CODE_SPACE: u32 = 1 << MAX_CODE_BITS;
pub const ADLER_MOD: u32 = 65_521;
pub const ADLER_NMAX: usize = 5_552;
pub const C_IN: u128 = 512;
pub const C_OUT: u128 = 8;
pub const C_INFL_FIXED: u128 = 4_096;
pub const C_SEG: u128 = 1;
/// T-SEG's domain ceiling, independent of PNG's configurable MAX_INPUT cap.
pub const SEGMENT_BYTES_MAX: u64 = 1 << 60;
