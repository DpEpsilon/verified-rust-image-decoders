//! Authored fixed-step effects at independently selected limits and windows.
use crate::{model as m, witness_match as t};
use vstd::prelude::*;
verus! {
pub(crate) open spec fn step(raw: Seq<u8>, s: t::Step, limit: nat, window: nat) -> m::SymbolEffect {
    if s.symbol == 256 {m::SymbolEffect::End {out:raw,position:s.next}}
    else if s.symbol > 256 && s.distance > window {
        m::SymbolEffect::Error {error:m::InflateFault::DistanceTooFar,out:raw.take(s.before as int),position:s.next}
    } else if s.after > limit {m::SymbolEffect::Full {out:raw.take(limit as int)}}
    else {m::SymbolEffect::Next {out:raw.take(s.after as int),position:s.next}}
}
proof fn effect(z: Seq<u8>, raw: Seq<u8>, s: t::Step, last: bool, limit: nat, window: nat)
    requires t::valid_step(z,raw,s,last), s.before <= limit, 1 <= window <= 32768,
    ensures m::MCompressedStep(z,s.pos,raw.take(s.before as int),limit,window,m::fixed_lit_lengths(),m::fixed_dist_lengths()) == step(raw,s,limit,window),
{
    hide(m::MDec); hide(m::decode_prefix); hide(m::cw); hide(m::copy_distance);
    assert(crate::limits::FIXED_LIT_COUNT == 288) by (compute);
    assert(crate::limits::FIXED_DIST_COUNT == 32) by (compute);
    assert(crate::limits::WINDOW_MAX == 32768) by (compute);
    assert(crate::limits::LEN_MAX == 258) by (compute);
    crate::witnesses::fixed_decode(z,s.pos,s.symbol as int);
    if s.symbol < 256 {
        assert(raw.take(s.before as int).push(raw[s.before as int]) =~= raw.take(s.after as int));
        if s.before == limit {assert(raw.take(s.before as int) == raw.take(limit as int));}
    } else if s.symbol == 256 {
        assert(raw.take(s.before as int) =~= raw);
    } else {
        crate::witnesses::fixed_dist_decode(z,s.pos+t::width(s.symbol)+m::length_extra(s.symbol),s.ds as int);
        if s.distance <= window {
            let fit = if s.after <= limit {s.length} else {(limit-s.before) as nat};
            t::copy_quant(raw,s.before,s.distance,0,s.length);
            t::copy_prefix(raw,s.before,s.distance,fit);
            assert(m::copy_distance(raw.take(s.before as int),s.distance,fit) == raw.take((s.before+fit) as int));
        }
    }
    reveal(m::MCompressedStep);
}
pub(crate) proof fn effects(z: Seq<u8>, raw: Seq<u8>, ts: Seq<t::Step>, a: nat, b: nat, limit: nat, window: nat)
    requires a <= b <= ts.len(), t::trace(z,raw,ts,a,b), 1 <= window <= 32768,
    ensures forall|j:int| a <= j < b ==> t::valid_step(z,raw,#[trigger] ts[j],j+1 == ts.len()),
        forall|j:int| a <= j < b && j+1 < ts.len() ==> ts[j+1].pos == ts[j].next && ts[j+1].before == ts[j].after,
        forall|j:int| a <= j < b && ts[j].before <= limit ==> #[trigger] m::MCompressedStep(z,ts[j].pos,raw.take(ts[j].before as int),limit,window,m::fixed_lit_lengths(),m::fixed_dist_lengths()) == step(raw,ts[j],limit,window),
    decreases b-a,
{
    if a < b {
        if b == a+1 {if ts[a as int].before <= limit {effect(z,raw,ts[a as int],a+1 == ts.len(),limit,window);}}
        else {let mid = (a+(b-a)/2) as nat; effects(z,raw,ts,a,mid,limit,window); effects(z,raw,ts,mid,b,limit,window);}
    }
}
pub(crate) open spec fn result(raw: Seq<u8>, ts: Seq<t::Step>, k: nat, limit: nat, window: nat) -> m::StoredEffect
    decreases ts.len()-k,
{
    if k >= ts.len() {m::StoredEffect::OutsideDomain}
    else {match step(raw,ts[k as int],limit,window) {
        m::SymbolEffect::Next {..} => result(raw,ts,k+1,limit,window),
        m::SymbolEffect::End {out,position} => m::StoredEffect::End {out,position},
        m::SymbolEffect::Full {out} => m::StoredEffect::Full {out},
        m::SymbolEffect::Error {error,out,position} => m::StoredEffect::Error {error,out,position},
        _ => m::StoredEffect::OutsideDomain,
    }}
}
pub(crate) proof fn expand(z: Seq<u8>, raw: Seq<u8>, ts: Seq<t::Step>, k: nat, limit: nat, window: nat)
    requires k < ts.len(), ts[k as int].before <= limit, 1 <= window <= 32768,
        forall|j:int| k <= j < ts.len() ==> t::valid_step(z,raw,#[trigger] ts[j],j+1 == ts.len()),
        forall|j:int| k <= j < ts.len() && j+1 < ts.len() ==> ts[j+1].pos == ts[j].next && ts[j+1].before == ts[j].after,
        forall|j:int| k <= j < ts.len() && ts[j].before <= limit ==> #[trigger] m::MCompressedStep(z,ts[j].pos,raw.take(ts[j].before as int),limit,window,m::fixed_lit_lengths(),m::fixed_dist_lengths()) == step(raw,ts[j],limit,window),
    ensures m::MCompressed(z,ts[k as int].pos,raw.take(ts[k as int].before as int),limit,window,m::fixed_lit_lengths(),m::fixed_dist_lengths()) == result(raw,ts,k,limit,window),
    decreases ts.len()-k,
{
    hide(m::MCompressedStep);
    if step(raw,ts[k as int],limit,window) is Next {expand(z,raw,ts,k+1,limit,window);}
    reveal_with_fuel(m::MCompressed,2);
}
} // verus!
