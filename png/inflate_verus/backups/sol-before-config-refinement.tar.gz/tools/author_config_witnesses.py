#!/usr/bin/env python3
"""Author fixed-stream window/limit gates from independent sample and encoder intent.

The imported authoring module replays samples and forward filters only; importing
it does not write generated files. Complete forward encodings select eligible
traces. Neither raw bytes nor effects come from reading compressed symbols.
"""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import author_extended_classes as a
V={v['name']:v for v in a.V}
P={v['name']:v for v in json.loads((ROOT.parent/'policy-draft/VECTORS-POLICY.json').read_text())}
def parts(data):
    return [b for k,b in a.chunks(data) if k==b'IDAT']
def candidate(raw,lazy=False,minimum=3,origin=1):
    # Independent slow-encoder choice: shortest-distance longest match; optional
    # one-position lazy lookahead and filtered-strategy short-match suppression.
    ts=[];p=0
    def match(p):
        n,d=a.match(raw,p,False,origin) if p>=origin else (0,0)
        return (n,d) if n>=minimum else (0,0)
    while p<len(raw):
        n,d=match(p)
        if n and lazy and match(p+1)[0]>n:n=0
        if n:ts.append((n,d));p+=n
        else:ts.append(raw[p]);p+=1
    return ts

def fast_candidate(raw):
    # Level-one forward policy: stop at a match of eight bytes, inspect at most
    # four equal three-byte keys, and insert skipped positions only for matches
    # no longer than four bytes. The search never consults compressed input.
    p=0;tokens=[];inserted=[]
    while p<len(raw):
        n=d=0;seen=0
        for q in reversed(inserted):
            if raw[q:q+3]!=raw[p:p+3]:continue
            seen+=1;length=0
            while length<258 and p+length<len(raw) and raw[q+length]==raw[p+length]:length+=1
            if length>=3 and length>n:n,d=length,p-q
            if n>=8 or seen>=4:break
        if p:inserted.append(p)
        if n:
            tokens.append((n,d))
            if n<=4:inserted.extend(range(p+1,p+n))
            p+=n
        else:tokens.append(raw[p]);p+=1
    return tokens

def steps(tokens):
    out=[];p=19;before=0
    for token in tokens+[256]:
        if isinstance(token,int):
            s=token;le=ds=de=n=d=0;nxt=p+(8 if s<144 else 9 if s<256 else 7);after=before+(s<256)
        else:
            n,d=token;s,le,ln,ds,de,dn=a.codes(n,d);nxt=p+(7 if s<280 else 8)+ln+5+dn;after=before+n
        out.append(dict(pos=p,next=nxt,before=before,after=after,symbol=s,le=le,ds=ds,de=de,length=n,distance=d));p=nxt;before=after
    return out

def effect(raw,ss,L,W):
    # Effects follow authored tokens, never compressed-input interpretation.
    for s in ss:
        if s['symbol']==256:return 'Done',raw,s['next']
        if s['symbol']>256 and s['distance']>W:return 'DistanceTooFar',raw[:s['before']],s['next']
        if s['after']>L:return 'Full',raw[:L],None
    raise AssertionError('authored trace has no end')
def model_effect(status,raw,pos):
    rs=a.seq(raw)
    if status=='Full':return 'm::StoredEffect::Full {out:'+rs+'}'
    if status=='Done':return 'm::StoredEffect::End {out:'+rs+',position:'+str(pos)+'}'
    return 'm::StoredEffect::Error {error:m::InflateFault::'+status+',out:'+rs+',position:'+str(pos)+'}'
def ms(s):return 'm::InflateStatus::'+s if s in ('Done','Full') else 'm::InflateStatus::Error(m::InflateFault::'+s+')'
def es(s):return 'Status::'+s if s in ('Done','Full') else 'Status::Err(E::'+s+')'

claims=[]
def add(ident,name,raw,tokens=None,domain='core',records=None,finish='Done'):
    vectors=V if domain=='core' else P;data=bytes.fromhex(vectors[name]['input_hex']);ps=parts(data);z=b''.join(ps)
    if tokens is None:
        for lazy in (False,True):
            for minimum in (3,6):
                trial=candidate(raw,lazy,minimum)
                if a.encode(trial)==z[2:-4]:tokens=trial;break
            if tokens is not None:break
    assert tokens is not None, name
    body=a.encode(tokens)
    assert z[2:2+len(body)]==body, name
    r=a.image_r(data);assert r is not None
    ss=steps(tokens);n=len(raw);adler=(sum((n-i)*v for i,v in enumerate(raw))+n)%65521*65536+(1+sum(raw))%65521
    calls=[]
    for L,e,t in ([(L,e,t) for L in (r,r+1) for e in (True,False) for t in (False,True)] if domain=='policy' else [(r,True,False)]):
        W=2**(z[0]//16+8) if e else 32768;status,output,pos=effect(raw,ss,L,W)
        if status=='Done':
            status=finish
            if status=='Done' and (ss[-1]['next']+7)//8+4<len(z):status='Done' if t and n==L else 'TrailingZlibData'
        calls.append(dict(limit=L,enforce=e,ignore_tail=t,status=status,raw=output,window=W))
    claims.append(dict(class_=ident,domain=domain,members=[[x,0] for x in (records or [name])],r=r,raw=raw,steps=ss,tokens=tokens,segment_lengths=[len(x) for x in ps],calls=calls,intent={'schedule':'base-or-window-authored','record':name},adler=adler,wire=z,parts=ps))

for suffix in ('level1-default','level1-fixed','level1-filtered'):
    add(suffix.replace('-','_'),'zlib/'+suffix,a.base_raw,fast_candidate(a.base_raw))
for suffix in ('level6-fixed','level9-fixed','level6-filtered','level9-filtered','window-9','window-10','window-12'):
    add(suffix.replace('-','_'),'zlib/'+suffix,a.base_raw)
add('short_image','image/truncated-data',a.base_raw[:-5])
for suffix,value in [('5',5),('255',255)]:
    raw=a.base_raw.copy();raw[93*3]=value;add('filter_type_'+suffix,'image/filter-type-'+suffix,raw)
raw=a.base_raw.copy();raw[0]=9
add('adler_before_filter','precedence/adler-before-filter',raw,candidate(raw),finish='AdlerMismatch')
for suffix,raw in [('data',a.base_raw+[0]),('row',a.base_raw+a.base_raw[:93])]:add('excess_'+suffix,'image/excess-'+suffix,raw)
add('empty_adam7_passes','interlace/1x1-filter-bytes-for-empty-passes',[0,5]+[0]*6)
raw=a.window_raw[:400]+a.window_raw[100:103];tokens=a.window_raw[:400]+[(3,300)]
for suffix in ('beyond','within'):add('declared_'+suffix,'deflate/distance-'+suffix+'-declared-window',raw,tokens)
for suffix,raw in [('excess-output-stays-an-error',a.base_raw+[0]),('excess-row-stays-an-error',a.base_raw+a.base_raw[:93]),('excess-output-and-trailing-byte',a.base_raw+[0])]:
    prefix='policy/zlib-tail/'+suffix
    add('policy_'+suffix.replace('-','_'),prefix+'/strict',raw,candidate(raw),domain='policy',records=[prefix+'/strict',prefix+'/recommended-beta'])
prefix='policy/window/distance-beyond-declared-window'
add('policy_declared_beyond',prefix+'/strict',a.window_raw[:400]+a.window_raw[100:103],a.window_raw[:400]+[(3,300)],domain='policy',records=[prefix+'/strict',prefix+'/recommended-beta'])

lines=['//! Independently authored fixed-window, short/full image and policy gates.',
'use crate::{model as m, witness_match as t, witness_checksum as c, witness_config as g, witness_policy::check_policy_parts, Status, InflateError as E};','use vstd::prelude::*;','verus! {']
for cl in claims:
    ident=cl.pop('class_');cl['class']=ident;z=cl['wire'];raw=cl['raw'];ss=cl['steps'];ps=cl['parts'];n=len(raw)
    zs=a.seq(z);rs=a.seq(raw);ts='seq!['+', '.join('t::Step {'+', '.join(f'{k}:{v}' for k,v in s.items())+'}' for s in ss)+']'
    sb=sum(raw);sp=sum((n-i)*v for i,v in enumerate(raw))+n;adler=cl['adler']
    lines += [f'spec fn {ident}_z() -> Seq<u8> {{ {zs} }}',f'spec fn {ident}_raw() -> Seq<u8> {{ {rs} }}',f'spec fn {ident}_ts() -> Seq<t::Step> {{ {ts} }}']
    for i,part in enumerate(ps):
        lines += [f'fn {ident}_part_{i}() -> (wire: [u8;{len(part)}])',f'    ensures wire@ == {a.seq(part)},','{','    ['+', '.join(hex(x)+('u8' if j==0 else '') for j,x in enumerate(part))+']','}']
    lines += ['#[verifier::spinoff_prover]',f'proof fn {ident}_trace()',f'    ensures {ident}_z().len() == {len(z)}, {ident}_raw().len() == {n}, {ident}_ts().len() == {len(ss)},',f'        {ident}_ts()[0].pos == 19, {ident}_ts()[0].before == 0,',f'        t::trace({ident}_z(),{ident}_raw(),{ident}_ts(),0,{len(ss)}),','{',f'    assert(t::trace({zs},{rs},{ts},0,{len(ss)})) by (compute);','}',
        '#[verifier::spinoff_prover]',f'proof fn {ident}_checksum()',f'    ensures m::Adler({ident}_raw()) == {adler},','{','    hide(m::sum_bytes); hide(m::sum_prefixes);',f'    assert(c::sums({rs},0,{n}) == ({sb}nat,{sp}nat)) by (compute);',f'    c::sums_correct({ident}_raw(),0,{n}); assert({ident}_raw().subrange(0,{n}) =~= {ident}_raw());','    assert(crate::limits::ADLER_MOD == 65521) by (compute); assert(m::pow2(16) == u16::MAX+1) by (compute);',f'    assert(({sp}nat%65521)*(u16::MAX as nat+1)+(1+{sb}nat)%65521 == {adler}) by (compute);','}']
    # Keep concrete metadata and effect interpretation in a query separate from
    # the symbolic model/public-call composition. Duplicate option queries share facts.
    for j,call in enumerate(cl['calls']):
        L,W=call['limit'],call['window'];e,t=str(call['enforce']).lower(),str(call['ignore_tail']).lower();s,out,pos=effect(raw,ss,L,W);eff=model_effect(s,out,pos)
        finish_eff=model_effect(call['status'],call['raw'],8*len(z) if call['status']=='Done' else 8*((ss[-1]['next']+7)//8+(5 if call['status']=='TrailingZlibData' else 4)))
        lines += ['#[verifier::spinoff_prover]',f'proof fn {ident}_facts_{j}()',f'    ensures {ident}_z()[0] == {z[0]}, {ident}_z()[1] == {z[1]},',f'        m::window_size({z[0]//16},{e}) == {W},',f'        m::field_value({ident}_z(),16,1) == 1, m::field_value({ident}_z(),17,2) == 1,',f'        g::result({ident}_raw(),{ident}_ts(),0,{L},{W}) == ({eff}),']
        if s=='Done':lines += [f'        m::MFinish({ident}_z(),{ss[-1]["next"]},{ident}_raw(),{L},{t}) == ({finish_eff}),']
        lines += ['{',f'    assert(m::window_size({z[0]//16},{e}) == {W}) by (compute);',f'    assert(m::field_value({zs},16,1) == 1) by (compute); assert(m::field_value({zs},17,2) == 1) by (compute);',f'    assert(g::result({ident}_raw(),{ident}_ts(),0,{L},{W}) == ({eff})) by (compute);']
        if s=='Done':
            lines += [f'    {ident}_checksum();',f'    assert(m::be_value({zs},{(ss[-1]["next"]+7)//8},4) == {int.from_bytes(z[(ss[-1]["next"]+7)//8:][:4],"big")}) by (compute);']
        lines += ['}']
    lines += ['#[verifier::spinoff_prover]',f'fn {ident}() {{',f'    hide({ident}_z); hide({ident}_raw); hide({ident}_ts); hide(m::sum_bytes); hide(m::sum_prefixes); hide(m::MCompressedStep); hide(g::result); hide(g::step);']
    for i in range(len(ps)):lines += [f'    let segment_{i} = {ident}_part_{i}();']
    lines += [f'    let parts: [&[u8];{len(ps)}] = ['+', '.join('&segment_'+str(i) for i in range(len(ps)))+'];',f'    let ghost raw = {ident}_raw();','    proof {',f'        {ident}_trace();',f'        reveal_with_fuel(crate::segments::parts_prefix,{len(ps)+1}); assert(crate::segments::parts_prefix(parts@,{len(ps)}) =~= {ident}_z());',f'        assert(crate::limits::SEGMENT_BYTES_MAX >= {len(z)}) by (compute);','    }']
    for j,call in enumerate(cl['calls']):
        L,W=call['limit'],call['window'];e,t=str(call['enforce']).lower(),str(call['ignore_tail']).lower()
        lines += ['    proof {',f'        {ident}_facts_{j}();',f'        g::effects({ident}_z(),{ident}_raw(),{ident}_ts(),0,{len(ss)},{L},{W});',f'        g::expand({ident}_z(),{ident}_raw(),{ident}_ts(),0,{L},{W});',f'        assert({ident}_raw().take(0) =~= Seq::<u8>::empty());',f'        assert(m::Inflate({ident}_z(),{L},{e},{t}).status == {ms(call["status"])});',f'        assert(m::Inflate({ident}_z(),{L},{e},{t}).out == {a.seq(call["raw"])});','    }',f'    let ghost expected = {a.seq(call["raw"])}; let mut output = [0xa5u8;{L}]; check_policy_parts(&parts,&mut output,{e},{t},{es(call["status"])},Ghost(expected));']
    lines += ['}']
    del cl['wire'];del cl['parts']
lines += ['} // verus!','']
(ROOT/'src/witness_config_cases.rs').write_text('\n'.join(lines))
(ROOT/'tools/witness_config.json').write_text(json.dumps(claims,indent=2)+'\n')
print('Authored',len(claims),'fixed configuration classes;',sum(len(x['members']) for x in claims if x['domain']=='core'),'core streams and',sum(len(x['members']) for x in claims if x['domain']=='policy'),'policy records')
