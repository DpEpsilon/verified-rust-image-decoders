//! Symbolic stored-stream composition, separate from concrete transcriptions.
use crate::{model as m, witness_literal_class::stored_payload};
use vstd::prelude::*;
verus! {
pub(crate) proof fn stored_stream(z: Seq<u8>, raw: Seq<u8>, n: nat, cmf: nat, flg: nat, checksum: nat)
    requires raw.len() == n, n <= u16::MAX, z.len() == n+11,
        z.subrange(7,(7+n) as int) == raw,
        z[3] as nat + 256*z[4] as nat == n, z[5] as nat + 256*z[6] as nat == u16::MAX-n,
        m::field_value(z,16,1) == 1, m::field_value(z,17,2) == 0,
        m::be_value(z,0,1) == cmf, m::be_value(z,1,1) == flg,
        cmf == 120, flg < 256, (cmf*256+flg)%31 == 0, (flg/32)%2 == 0,
        m::be_value(z,(7+n) as nat,4) == checksum, m::Adler(raw) == checksum,
    ensures m::Inflate(z,n,true,false).status == m::InflateStatus::Done,
        m::Inflate(z,n,true,false).out == raw,
{
    hide(m::sum_bytes); hide(m::sum_prefixes); hide(m::MStoredPayload);
    assert(crate::limits::WINDOW_MAX == 32768) by (compute);
    assert(m::pow2(15) == 32768) by (compute);
    stored_payload(z,raw);
    assert(m::MStoredBlock(z,19,Seq::empty(),n) == (m::StoredEffect::End {out:raw,position:8*(7+n)}));
    assert(m::MBlk(z,16,Seq::empty(),n,32768,true) == (m::StoredEffect::End {out:raw,position:8*(7+n)}));
    assert(m::MFinish(z,8*(7+n),raw,n,false) == (m::StoredEffect::End {out:raw,position:8*z.len()}));
}
} // verus!
