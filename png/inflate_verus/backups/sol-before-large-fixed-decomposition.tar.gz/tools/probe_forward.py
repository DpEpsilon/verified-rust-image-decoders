#!/usr/bin/env python3
"""Group frozen streams under independently authored fixed-match and larger stored traces.

RGB pixels are the frozen encoder's TPX, recovered by replaying its RNG/encoder
prefix (not a decoder): (201,73,63),(202,75,151),(225,26,23),(252,246,129).
Row 0 uses filter 0; row 1 uses Sub (filter 1), giving the raw below.
Palette samples are authored (0,1),(2,1): filter-0 [0,0,1], Sub [1,2,255].
The one-pixel packed rows have filter 0 and authored packed byte 0 or 128.
No expected result field, decompressor or executable decode table is consulted.
"""
import json
import random
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
V = json.loads((ROOT.parent/'spec-frozen/VECTORS.json').read_text())
def chunks(data):
    p = 8
    while p+12 <= len(data):
        n = int.from_bytes(data[p:p+4],'big')
        if p+12+n > len(data) or n > 1<<28: return
        yield data[p+4:p+8], data[p+8:p+8+n]
        p += n+12
def streams(data):
    idat = None; frames = []
    for k,b in chunks(data):
        if k == b'IDAT':
            if idat is None: idat = []
            idat.append(b)
        elif k == b'fcTL': frames.append(None)
        elif k == b'fdAT' and frames and len(b) >= 4:
            if frames[-1] is None: frames[-1] = []
            frames[-1].append(b[4:])
    return [b''.join(p) for p in ([] if idat is None else [idat])+[f for f in frames if f is not None]]
def seq(xs,ty='u8'):
    return 'seq!['+', '.join(str(x)+(ty if i == 0 else '') for i,x in enumerate(xs))+']'
# Representative names select input bytes only. Expected raw bytes are authored.
CASES = [('rgb_2x2','container/minimal-ok',[0,201,73,63,202,75,151,1,225,26,23,27,220,106]),
         ('palette_2x2','plte/ok',[0,0,1,1,2,255]),
         ('packed_zero','ok/ct0-d1-il0-1x1',[0,0]),
         ('packed_high','ok/ct0-d1-il1-1x1',[0,128])]
def image_r(data):
    hs = [b for k,b in chunks(data) if k == b'IHDR' and len(b) == 13]
    if len(hs) != 1: return None
    h = hs[0]; w = int.from_bytes(h[:4],'big'); height = int.from_bytes(h[4:8],'big')
    d,ct,cm,fm,il = h[8:]; channels = {0:1,2:3,3:1,4:2,6:4}.get(ct)
    legal = {0:(1,2,4,8,16),2:(8,16),3:(1,2,4,8),4:(8,16),6:(8,16)}
    if not (0 < w < 1<<31 and 0 < height < 1<<31 and ct in legal and d in legal[ct] and cm == fm == 0 and il in (0,1)): return None
    grids = [(0,0,1,1)] if il == 0 else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    size = 0
    for x,y,dx,dy in grids:
        pw = max(0,(w+dx-1-x)//dx); ph = max(0,(height+dy-1-y)//dy)
        if pw and ph: size += ph*(1+(pw*channels*d+7)//8)
    return size

def pack(values,d):
    if d == 16: return b''.join(v.to_bytes(2,'big') for v in values)
    if d == 8: return bytes(values)
    out = []; a = n = 0
    for v in values:
        a = (a<<d)|v; n += d
        if n == 8: out.append(a); a = n = 0
    if n: out.append(a<<(8-n))
    return bytes(out)

def scan_intent(px,w,h,ct,d,il,filters=None):
    channels = {0:1,2:3,3:1,4:2,6:4}[ct]; bpp = max(1,channels*d//8)
    grids = [(0,0,1,1)] if il == 0 else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    out = []; rownum = 0
    for x0,y0,dx,dy in grids:
        xs = list(range(x0,w,dx)); ys = list(range(y0,h,dy))
        if not xs or not ys: continue
        prev = bytes(len(pack([0]*(len(xs)*channels),d)))
        for y in ys:
            row = pack([v for x in xs for v in px[y*w+x]],d); ft = rownum%5 if filters is None else filters; out.append(ft)
            for i,v in enumerate(row):
                a = row[i-bpp] if i >= bpp else 0; b = prev[i]; c = prev[i-bpp] if i >= bpp else 0
                pa,pb,pc = abs(b-c),abs(a-c),abs(a+b-2*c)
                predictor = [0,a,b,(a+b)//2,a if pa <= pb and pa <= pc else b if pb <= pc else c][ft]
                out.append((v-predictor)&255)
            prev = row; rownum += 1
    return out

def literal_body(raw):
    # Forward RFC fixed-code encoding is an eligibility check, not a decoder.
    bits = [1,1,0]
    for s in raw+[256]:
        width = 8 if s < 144 else 9 if s < 256 else 7
        word = 48+s if s < 144 else 256+s if s < 256 else 0
        bits += [(word>>i)&1 for i in range(width-1,-1,-1)]
    return bytes(sum(v<<j for j,v in enumerate(bits[i:i+8])) for i in range(0,len(bits),8))

def stored_body(raw):
    n = len(raw)
    return bytes([1])+n.to_bytes(2,'little')+(65535-n).to_bytes(2,'little')+bytes(raw)


# RFC forward encoder intent, not executable inflate tables.
LBASE=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258]
LEXTRA=[0]*8+[1]*4+[2]*4+[3]*4+[4]*4+[5]*4+[0]
DBASE=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577]
DEXTRA=[0]*4+[i for i in range(1,14) for _ in range(2)]
def codes(n,d):
    li=max(i for i,b in enumerate(LBASE) if b<=n);di=max(i for i,b in enumerate(DBASE) if b<=d)
    return 257+li,n-LBASE[li],LEXTRA[li],di,d-DBASE[di],DEXTRA[di]
def encode(tokens):
    bits=[1,1,0]
    def field(v,n):bits.extend((v>>i)&1 for i in range(n))
    def code(s):
        n=8 if s<144 else 9 if s<256 else 7 if s<280 else 8
        w=48+s if s<144 else 256+s if s<256 else s-256 if s<280 else s-88
        bits.extend((w>>i)&1 for i in range(n-1,-1,-1))
    for t in tokens:
        if isinstance(t,int):code(t)
        else:
            s,le,ln,ds,de,dn=codes(*t);code(s);field(le,ln)
            bits.extend((ds>>i)&1 for i in range(4,-1,-1));field(de,dn)
    code(256)
    return bytes(sum(v<<j for j,v in enumerate(bits[i:i+8])) for i in range(0,len(bits),8))
def match(raw,p,oldest,origin=0):
    best=(0,0)
    for d in range(1,min(p-origin,32768)+1):
        n=0
        while n<258 and p+n<len(raw) and raw[p+n]==raw[p+n-d]:n+=1
        if n>=3 and (n>best[0] or oldest and n==best[0]):best=(n,d)
    return best

def greedy(raw,prefix,lazy,oldest,origin=0):
    ts=[];p=0
    while p<len(raw):
        n,d=match(raw,p,oldest,origin) if p>=prefix else (0,0)
        if n and lazy and match(raw,p+1,oldest,origin)[0]>n:n=0
        if n:ts.append((n,d));p+=n
        else:ts.append(raw[p]);p+=1
    return ts

# Each fdAT stream uses the dimensions of its own enclosing fcTL, not the canvas.
def stream_rs(data):
    hs = [b for k,b in chunks(data) if k == b'IHDR' and len(b) == 13]
    if len(hs) != 1: return [None]*len(streams(data))
    head = hs[0]; has_idat = False; frames = []
    for k,b in chunks(data):
        if k == b'IDAT': has_idat = True
        elif k == b'fcTL': frames.append([b,False])
        elif k == b'fdAT' and len(b) >= 4 and frames: frames[-1][1] = True
    rs = [image_r(data)] if has_idat else []
    for ctl,present in frames:
        if not present: continue
        if len(ctl) != 26: rs.append(None); continue
        # Reuse only the shape calculation, with an independently formed IHDR.
        shape = ctl[4:12]+head[8:]
        rs.append(image_r(bytes(8)+bytes([0,0,0,13])+b'IHDR'+shape+bytes(4)))
    return rs

CASES = []; TRACES = {}; REPS = {}; INTENTS = {}
base = json.loads((ROOT/'tools/witness_classes.json').read_text())
covered = {tuple(member) for c in base for member in c['members']}
for source in ('witnesses.rs','witness_cases.rs','witness_dynamic_cases.rs','witness_d4.rs','witness_overlap.rs','witness_invalid_dynamic.rs','witness_repeats.rs','witness_single_literal.rs'):
    for line in (ROOT/'src'/source).read_text().splitlines():
        if line.startswith('/// ') and ':' in line: covered.add((line[4:].split(':')[0],0))
known = set()
for c in base:
    name,index = c['members'][0]
    known.add(streams(bytes.fromhex(next(v['input_hex'] for v in V if v['name']==name)))[index])
a=json.loads((ROOT/'tools/witness_extended.json').read_text())
raw=next(c['raw'] for c in a if c['class']=='base_stored')
def rle(raw):
    ts=[];p=0
    while p<len(raw):
        n=0
        while p>0 and n<258 and p+n<len(raw) and raw[p+n]==raw[p+n-1]:n+=1
        if n>=3:ts.append((n,1));p+=n
        else:ts.append(raw[p]);p+=1
    return ts
trial=rle(raw)
for v in V:
 if v['name'].startswith('zlib/'):
  zs=streams(bytes.fromhex(v['input_hex']))
  if zs and encode(trial)==zs[0][2:-4]:print('RLE',v['name'],len(trial))
for lazy in (False,True):
 for oldest in (False,True):
  for origin in (0,1):
   ts=greedy(raw,1,lazy,oldest,origin)
   for v in V:
    if v['name'].startswith('zlib/') or v['name'].startswith('idat/'):
     zs=streams(bytes.fromhex(v['input_hex']))
     if zs and encode(ts)==zs[0][2:-4]:print('GREEDY',v['name'],lazy,oldest,origin,len(ts))
