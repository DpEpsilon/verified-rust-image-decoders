use crate::{
    adler::Adler,
    bits::Bits,
    huffman::{Huffman, Kind},
    limits::*,
    InflateError as E, InflateOptions, InflateResult, Segments, Status, Window, Work, ZlibTail,
};
#[cfg(verus_only)]
use crate::model as m;
use vstd::prelude::*;

const LEN_BASE: [u16; 29] = [
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131,
    163, 195, 227, 258,
];
const LEN_EXTRA: [u8; 29] = [
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0,
];
const DIST_BASE: [u16; NDIST_MAX] = [
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537,
    2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577,
];
const DIST_EXTRA: [u8; NDIST_MAX] = [
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13,
    13,
];
const CL_ORDER: [usize; NCL] = [
    16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15,
];

/// The public signatures require ring.len() == WINDOW_MAX for measuring, and
/// a fresh source satisfying Segments' contract. A typed array inside the sink
/// prevents accidental indexing of a shorter ring. No stream-driven allocation.
verus! {

/// Representation only: the independent model never reads this predicate.
closed spec fn ring_repr(ring: Seq<u8>, out: Seq<u8>) -> bool {
    ring.len() == WINDOW_MAX && forall|i: int|
        0 <= i < out.len() && out.len() - WINDOW_MAX <= i ==>
            #[trigger] ring[i % WINDOW_MAX as int] == out[i]
}

proof fn lemma_recent_distinct(k: nat, distance: nat)
    requires 1 <= distance < WINDOW_MAX, distance <= k,
    ensures (k as int) % (WINDOW_MAX as int) != (k - distance) % (WINDOW_MAX as int),
{
    vstd::arithmetic::div_mod::lemma_mod_equivalence(k as int, (k - distance) as int, WINDOW_MAX as int);
    vstd::arithmetic::div_mod::lemma_small_mod(distance, WINDOW_MAX as nat);
}

proof fn lemma_skip_later(a: Seq<u8>, b: Seq<u8>, p: int, q: int)
    requires a.len() == b.len(), 0 <= p <= q <= a.len(), a.skip(p) == b.skip(p),
    ensures a.skip(q) == b.skip(q),
{
    vstd::seq_lib::lemma_seq_skip_of_skip(a, p, q - p);
    vstd::seq_lib::lemma_seq_skip_of_skip(b, p, q - p);
    assert(a.skip(q) =~= a.skip(p).skip(q - p));
    assert(b.skip(q) =~= b.skip(p).skip(q - p));
}

proof fn lemma_ring_append(ring: Seq<u8>, out: Seq<u8>, byte: u8)
    requires ring_repr(ring, out),
    ensures ring_repr(ring.update((out.len() % WINDOW_MAX as nat) as int, byte), out.push(byte)),
{
    let slot = (out.len() % WINDOW_MAX as nat) as int;
    let next = ring.update(slot, byte);
    assert forall|i: int| 0 <= i < out.len() + 1 && out.len() + 1 - WINDOW_MAX <= i implies
        #[trigger] next[i % WINDOW_MAX as int] == out.push(byte)[i] by {
        if i < out.len() {
            lemma_recent_distinct(out.len(), (out.len() - i) as nat);
            assert(ring[i % WINDOW_MAX as int] == out[i]);
        } else { assert(i == out.len()); }
    }
}

enum Sink<'a> {
    Into(&'a mut [u8]),
    Ring(&'a mut [u8; WINDOW_MAX]),
}

closed spec fn sink_view(sink: Sink) -> Seq<u8> {
    match sink { Sink::Into(out) => out@, Sink::Ring(ring) => ring@ }
}

struct Output<'a> {
    sink: Sink<'a>,
    produced: u64,
    limit: u64,
    adler: Adler,
    out: Ghost<Seq<u8>>,
    initial: Ghost<Seq<u8>>,
}
impl<'a> Output<'a> {
    closed spec fn wf(&self) -> bool {
        self.produced == self.out@.len() && self.produced <= self.limit
        && self.adler.wf() && self.adler.data() == self.out@
        && match self.sink {
            Sink::Into(buffer) => buffer.len() == self.limit && self.initial@.len() == buffer.len()
                && buffer@.take(self.produced as int) == self.out@
                && buffer@.skip(self.produced as int) == self.initial@.skip(self.produced as int),
            Sink::Ring(ring) => ring_repr(ring@, self.out@),
        }
    }

    proof fn lemma_observation(&self)
        requires self.wf(),
        ensures self.produced == self.out@.len(), self.out@.len() <= self.limit,
    {}

    fn new(sink: Sink<'a>, limit: u64) -> (s: Self)
        requires match sink {
            Sink::Into(buffer) => buffer.len() == limit,
            Sink::Ring(ring) => ring@.len() == WINDOW_MAX,
        },
        ensures s.wf(), s.produced == 0, s.limit == limit, s.out@ == Seq::<u8>::empty(),
    {
        let initial = Ghost(sink_view(sink));
        let adler = Adler::new();
        proof {
            match &sink {
                Sink::Into(buffer) => {
                    assert(buffer@.take(0) =~= Seq::<u8>::empty());
                    assert(buffer@.skip(0) =~= initial@);
                },
                Sink::Ring(_) => {},
            }
        }
        Self { sink, produced: 0, limit, adler, out: Ghost(Seq::empty()), initial }
    }

    fn append_byte(&mut self, byte: u8) -> (r: Result<(), Status>)
        requires old(self).wf(),
        ensures final(self).wf(), final(self).limit == old(self).limit,
            final(self).initial == old(self).initial,
            match m::MEmit(old(self).out@, old(self).limit as nat, byte) {
                m::OutputEffect::Next { out } => r.is_ok() && final(self).out@ == out
                    && final(self).produced == old(self).produced + 1,
                m::OutputEffect::Full { out } => r == Err(Status::Full) && final(self).out@ == out
                    && final(self).produced == old(self).produced,
                _ => false,
            },
    {
        if self.produced == self.limit { return Err(Status::Full); }
        let ghost before = self.out@;
        match &mut self.sink {
            Sink::Into(out) => {
                let ghost previous = out@;
                proof {
                    assert(previous.skip(self.produced as int) == self.initial@.skip(self.produced as int));
                    lemma_skip_later(previous, self.initial@, self.produced as int, (self.produced + 1) as int);
                }
                out[self.produced as usize] = byte;
                proof {
                    assert(out@.take((self.produced + 1) as int) =~= before.push(byte));
                    assert(out@.skip((self.produced + 1) as int)
                        =~= self.initial@.skip((self.produced + 1) as int));
                }
            },
            Sink::Ring(ring) => {
                proof { lemma_ring_append(ring@, before, byte); }
                ring[(self.produced % WINDOW_MAX as u64) as usize] = byte;
            },
        }
        self.produced += 1;
        self.adler.update_byte(byte);
        proof { self.out = Ghost(before.push(byte)); }
        Ok(())
    }

    fn previous(&self, distance: u64) -> (byte: u8)
        requires self.wf(), 1 <= distance <= self.produced, distance <= WINDOW_MAX,
        ensures byte == self.out@[(self.produced - distance) as int],
    {
        let index = self.produced - distance;
        match &self.sink {
            Sink::Into(out) => out[index as usize],
            Sink::Ring(ring) => ring[(index % WINDOW_MAX as u64) as usize],
        }
    }
}

closed spec fn stored_eq(effect: m::StoredEffect, result: Result<(), Status>, out: Seq<u8>, position: nat) -> bool {
    match effect {
        m::StoredEffect::End { out: expected, position: end } => result.is_ok() && out == expected && position == end,
        m::StoredEffect::Full { out: expected } => result == Err(Status::Full) && out == expected,
        m::StoredEffect::Error { error, out: expected, position: end } => error == m::InflateFault::TruncatedZlib
            && result == Err(Status::Err(E::TruncatedZlib)) && out == expected && position == end,
        m::StoredEffect::OutsideDomain => false,
    }
}

/// The production stored-payload loop, after validated LEN/NLEN and alignment.
fn stored_payload<S: Segments>(br: &mut Bits<'_, S>, output: &mut Output<'_>, count: u16, w: &mut Work)
    -> (r: Result<(), Status>)
    requires old(br).wf(), old(br).remaining == 0, old(br).position() % 8 == 0,
        old(output).wf(), old(w).wf(),
    ensures final(br).wf(), final(br).remaining == 0, final(br).concat() == old(br).concat(),
        final(output).wf(), final(output).limit == old(output).limit,
        final(output).initial == old(output).initial, final(w).wf(),
        old(w).observed@ <= final(w).observed@ <= old(w).observed@ + 2 * count,
        stored_eq(m::MStoredPayload(old(br).concat(), old(br).position() / 8,
            old(output).out@, old(output).limit as nat, count as nat), r, final(output).out@, final(br).position()),
{
    hide(Output::wf);
    hide(ring_repr);
    hide(m::MStoredPayload);
    let ghost z = br.concat();
    let ghost start = br.position() / 8;
    let ghost original = output.out@;
    let ghost limit = output.limit;
    proof { br.lemma_bounds(); output.lemma_observation(); }
    let mut remaining = count;
    while remaining > 0
        invariant
            br.wf(), br.remaining == 0, br.concat() == z, z == old(br).concat(),
            start == old(br).position() / 8, start <= z.len(),
            br.position() == 8 * (start + count - remaining), br.position() <= 8 * z.len(),
            output.wf(), output.out@.len() <= limit, output.limit == limit, limit == old(output).limit,
            original == old(output).out@, output.initial == old(output).initial,
            w.wf(), old(w).observed@ <= w.observed@,
            w.observed@ == old(w).observed@ + 2 * (count - remaining),
            remaining <= count,
            m::MStoredPayload(z, start, original, limit as nat, count as nat)
                == m::MStoredPayload(z, br.position() / 8, output.out@, limit as nat, remaining as nat),
        decreases remaining,
    {
        let ghost cursor = br.position() / 8;
        let ghost before = output.out@;
        proof { m::lemma_stored_unfold(z, cursor, before, limit as nat, remaining as nat); }
        w.add(1);
        let byte = match br.byte(w) {
            Ok(byte) => byte,
            Err(e) => {
                proof { assert(cursor == z.len()); }
                return Err(Status::Err(e));
            }
        };
        match output.append_byte(byte) {
            Ok(()) => {},
            Err(status) => return Err(status),
        }
        remaining -= 1;
    }
    proof { m::lemma_stored_unfold(z, br.position() / 8, output.out@, limit as nat, 0); }
    Ok(())
}

} // verus!

struct Tables {
    fixed_lit: Huffman,
    fixed_dist: Huffman,
    lit: Huffman,
    dist: Huffman,
    code: Huffman,
}
impl Tables {
    fn new(w: &mut Work) -> Result<Self, E> {
        let mut tables = Self {
            fixed_lit: Huffman::new(w),
            fixed_dist: Huffman::new(w),
            lit: Huffman::new(w),
            dist: Huffman::new(w),
            code: Huffman::new(w),
        };
        let mut lengths = [0u8; FIXED_LIT_COUNT];
        w.add(FIXED_LIT_COUNT);
        let mut i = 0;
        while i < FIXED_LIT_COUNT {
            w.add(1);
            lengths[i] = if i < 144 {
                8
            } else if i < 256 {
                9
            } else if i < 280 {
                7
            } else {
                8
            };
            i += 1;
        }
        tables.fixed_lit.build(&lengths, Kind::LitLen, w)?;
        w.add(FIXED_DIST_COUNT);
        tables
            .fixed_dist
            .build(&[5; FIXED_DIST_COUNT], Kind::Dist, w)?;
        Ok(tables)
    }
    fn dynamic<S: Segments>(&mut self, br: &mut Bits<'_, S>, w: &mut Work) -> Result<(), E> {
        let nlen = br.get(5, w)? as usize + 257;
        let ndist = br.get(5, w)? as usize + 1;
        let ncode = br.get(4, w)? as usize + 4;
        if nlen > NLIT_MAX || ndist > NDIST_MAX {
            return Err(E::InvalidCodeLengths);
        }
        let mut cl = [0u8; NCL];
        w.add(NCL);
        let mut i = 0;
        while i < ncode {
            w.add(1);
            cl[CL_ORDER[i]] = br.get(3, w)? as u8;
            i += 1;
        }
        self.code.build(&cl, Kind::CodeLen, w)?;
        let mut lengths = [0u8; DYNAMIC_LENGTHS];
        w.add(DYNAMIC_LENGTHS);
        let total = nlen + ndist;
        i = 0;
        while i < total {
            w.add(1);
            let sym = self.code.decode(br, w)?;
            if sym < 16 {
                lengths[i] = sym as u8;
                i += 1;
            } else {
                let (value, repeat) = if sym == 16 {
                    if i == 0 {
                        return Err(E::InvalidCodeLengths);
                    }
                    (lengths[i - 1], 3 + br.get(2, w)? as usize)
                } else if sym == 17 {
                    (0, 3 + br.get(3, w)? as usize)
                } else {
                    (0, 11 + br.get(7, w)? as usize)
                };
                if repeat > total - i {
                    return Err(E::InvalidCodeLengths);
                }
                let end = i + repeat;
                while i < end {
                    w.add(1);
                    lengths[i] = value;
                    i += 1;
                }
            }
        }
        if lengths[256] == 0 {
            return Err(E::InvalidCodeLengths);
        }
        self.lit.build(&lengths[..nlen], Kind::LitLen, w)?;
        self.dist.build(&lengths[nlen..total], Kind::Dist, w)?;
        Ok(())
    }
}

fn compressed<S: Segments>(
    br: &mut Bits<'_, S>,
    output: &mut Output<'_>,
    lit: &Huffman,
    dist: &Huffman,
    window: u64,
    w: &mut Work,
) -> Result<(), Status> {
    loop {
        w.add(1);
        let sym = lit.decode(br, w).map_err(Status::Err)?;
        if sym < 256 {
            output.append_byte(sym as u8)?;
        } else if sym == 256 {
            return Ok(());
        } else {
            if sym > 285 {
                return Err(Status::Err(E::InvalidSymbol));
            }
            let index = usize::from(sym - 257);
            let length =
                u32::from(LEN_BASE[index]) + br.get(LEN_EXTRA[index], w).map_err(Status::Err)?;
            let ds = usize::from(dist.decode(br, w).map_err(Status::Err)?);
            if ds >= NDIST_MAX {
                return Err(Status::Err(E::InvalidSymbol));
            }
            let distance = u64::from(DIST_BASE[ds])
                + u64::from(br.get(DIST_EXTRA[ds], w).map_err(Status::Err)?);
            if distance > output.produced || distance > window {
                return Err(Status::Err(E::DistanceTooFar));
            }
            let mut j = 0;
            while j < length {
                w.add(1);
                // Resolve against the evolving output/ring, including overlap.
                let byte = output.previous(distance);
                output.append_byte(byte)?;
                j += 1;
            }
        }
    }
}

fn run<S: Segments>(
    br: &mut Bits<'_, S>,
    output: &mut Output<'_>,
    o: InflateOptions,
    w: &mut Work,
) -> Result<(), Status> {
    let cmf = br.byte(w).map_err(Status::Err)?;
    let flg = br.byte(w).map_err(Status::Err)?;
    if (u16::from(cmf) * 256 + u16::from(flg)) % 31 != 0 {
        return Err(Status::Err(E::InvalidZlibHeader));
    }
    if cmf & 15 != 8 || cmf >> 4 > 7 {
        return Err(Status::Err(E::UnsupportedZlibMethod));
    }
    if flg & 0x20 != 0 {
        return Err(Status::Err(E::ZlibPresetDictionary));
    }
    let window = match o.window {
        Window::Enforce => 1u64 << ((cmf >> 4) + 8),
        Window::Ignore => WINDOW_MAX as u64,
    };
    let mut tables = Tables::new(w).map_err(Status::Err)?;
    loop {
        w.add(1);
        let final_block = br.get(1, w).map_err(Status::Err)?;
        let block_type = br.get(2, w).map_err(Status::Err)?;
        match block_type {
            0 => {
                br.align();
                let lo = u16::from(br.byte(w).map_err(Status::Err)?);
                let hi = u16::from(br.byte(w).map_err(Status::Err)?);
                let nlo = u16::from(br.byte(w).map_err(Status::Err)?);
                let nhi = u16::from(br.byte(w).map_err(Status::Err)?);
                let len = lo | hi << 8;
                if len != !(nlo | nhi << 8) {
                    return Err(Status::Err(E::StoredLengthMismatch));
                }
                // The verified payload loop preserves D5's read-before-limit order.
                stored_payload(br, output, len, w)?;
            }
            1 => compressed(br, output, &tables.fixed_lit, &tables.fixed_dist, window, w)?,
            2 => {
                tables.dynamic(br, w).map_err(Status::Err)?;
                compressed(br, output, &tables.lit, &tables.dist, window, w)?;
            }
            _ => return Err(Status::Err(E::InvalidBlockType)),
        }
        if final_block != 0 {
            break;
        }
    }
    br.align();
    let mut expected = 0u32;
    let mut i = 0;
    while i < 4 {
        w.add(1);
        expected = (expected << 8) | u32::from(br.byte(w).map_err(Status::Err)?);
        i += 1;
    }
    if expected != output.adler.finish() {
        return Err(Status::Err(E::AdlerMismatch));
    }
    // IgnoreTail is inert for a short raster: only exactly-L output may ignore
    // bytes after the checked Adler-32 (OPTIONS.md's RecommendedBeta condition).
    if o.zlib_tail == ZlibTail::IgnoreTail && output.produced == output.limit {
        return Ok(());
    }
    w.add(1);
    if br.src.read().is_some() {
        return Err(Status::Err(E::TrailingZlibData));
    }
    Ok(())
}

fn entry<S: Segments>(src: &mut S, sink: Sink<'_>, limit: u64, o: InflateOptions) -> InflateResult {
    let mut output = Output::new(sink, limit);
    let mut work = Work::default();
    let mut br = Bits::new(src);
    let status = match run(&mut br, &mut output, o, &mut work) {
        Ok(()) => Status::Done,
        Err(s) => s,
    };
    InflateResult {
        status,
        produced: output.produced,
        core_steps: work.core,
        seg_steps: br.src.diagnostic_seg_steps(),
    }
}

/// Write at most out.len() bytes; preserve the unwritten suffix on every result.
/// Requires a fresh source satisfying Segments' contract. No allocation.
pub fn inflate_zlib_into<S: Segments>(
    src: &mut S,
    out: &mut [u8],
    o: InflateOptions,
) -> InflateResult {
    let limit = out.len() as u64;
    entry(src, Sink::Into(out), limit, o)
}

/// Measure using exactly WINDOW_MAX caller-owned bytes, whose initial contents
/// may be arbitrary. Requires a fresh source and ring.len() == WINDOW_MAX.
/// An invalid ring is a caller-contract violation, not an input-format error.
pub fn inflate_zlib_measure<S: Segments>(
    src: &mut S,
    ring: &mut [u8],
    limit: u64,
    o: InflateOptions,
) -> InflateResult {
    let ring: &mut [u8; WINDOW_MAX] = ring
        .try_into()
        .expect("inflate measure requires WINDOW_MAX ring bytes");
    entry(src, Sink::Ring(ring), limit, o)
}
